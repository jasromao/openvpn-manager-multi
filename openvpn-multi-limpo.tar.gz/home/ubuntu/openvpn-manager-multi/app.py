from flask import Flask, render_template, request, send_file, redirect, url_for
from flask_httpauth import HTTPBasicAuth
import subprocess
import os
import configparser

SERVIDORES_CONF = "/home/ubuntu/openvpn-manager-multi/servidores.conf"

def carregar_servidores():
    config = configparser.ConfigParser()
    config.read(SERVIDORES_CONF)
    return config

app = Flask(__name__)
auth = HTTPBasicAuth()

USERS = {
    "admin": "Hu82+1265"
}

@auth.verify_password
def verify_password(username, password):
    return USERS.get(username) == password

@app.route("/")
@auth.login_required
def index():
    config = carregar_servidores()
    servidores = []

    for secao in config.sections():
        servidores.append({
            "id": secao,
            "nome": config[secao].get("NOME", secao),
            "porta": config[secao].get("PORTA", ""),
            "vpn": config[secao].get("VPN_PREFIX", ""),
            "ativo": config[secao].get("ATIVO", "1")
        })

    status = subprocess.run(
        ["systemctl", "is-active", "openvpn-server@manual"],
        capture_output=True,
        text=True
    ).stdout.strip()

    if status == "active":
        status = "ONLINE"
    else:
        status = "OFFLINE"

    return render_template(
        "index.html",
        status=status,
        servidores=servidores
    )
@app.route("/servidor/<servidor_id>")
@auth.login_required
def selecionar_servidor(servidor_id):
    config = carregar_servidores()

    if servidor_id not in config.sections():
        return "Servidor não encontrado", 404

    return redirect(url_for("clientes", servidor=servidor_id))

@app.route("/clientes")
@auth.login_required
def clientes_todos():
    config = carregar_servidores()
    todos = []

    for servidor in config.sections():
        dados = config[servidor]

        easyrsa_dir = dados.get("EASYRSA_DIR")
        ccd_dir = dados.get("CCD_DIR")
        service = dados.get("SERVICE")

        if not easyrsa_dir or not ccd_dir or not service:
            continue

        instancia = service.split("@", 1)[1]

        pasta = f"{easyrsa_dir}/pki/issued"
        status_log = f"/run/openvpn-server/{instancia}-status.log"

        online = {}

        if os.path.exists(status_log):
            online_text = subprocess.run(
                ["sudo", "cat", status_log],
                capture_output=True,
                text=True
            ).stdout

            for linha in online_text.splitlines():
                if linha.startswith("CLIENT_LIST"):
                    partes = linha.split()
                    if len(partes) >= 4:
                        online[partes[1]] = partes[3]

        if not os.path.isdir(pasta):
            continue

        for f in os.listdir(pasta):
            if not f.endswith(".crt"):
                continue

            if f in ("server.crt", f"{servidor}.crt"):
                continue

            nome = f[:-4]
            estado = "ONLINE" if nome in online else "OFFLINE"
            ipvpn = online.get(nome, "-")
            rede = "-"

            ccd = f"{ccd_dir}/{nome}"

            if os.path.exists(ccd):
                redes = []

                with open(ccd) as ficheiro:
                    for linha in ficheiro:
                        linha = linha.strip()

                        if linha.startswith("ifconfig-push "):
                            partes = linha.split()
                            if len(partes) >= 2:
                                ipvpn = partes[1]

                        if linha.startswith("# rede_local="):
                            redes.append(linha.split("=", 1)[1].strip())

                        elif linha.startswith("iroute "):
                            partes = linha.split()
                            if len(partes) >= 2:
                                redes.append(partes[1])

                if redes:
                    rede = ", ".join(dict.fromkeys(redes))

            todos.append({
                "servidor": servidor,
                "nome": nome,
                "estado": estado,
                "ipvpn": ipvpn,
                "rede": rede,
            })

    return render_template(
        "clientes_todos.html",
        clientes=sorted(
            todos,
            key=lambda x: (x["servidor"].lower(), x["nome"].lower())
        )
    )

@app.route("/clientes/<servidor>")
@auth.login_required
def clientes(servidor):
    config = carregar_servidores()

    if servidor not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor]
    nome_servidor = dados.get("NOME", servidor)

    easyrsa_dir = dados.get("EASYRSA_DIR")
    ccd_dir = dados.get("CCD_DIR")
    service = dados.get("SERVICE")

    instancia = service.split("@", 1)[1]

    pasta = f"{easyrsa_dir}/pki/issued"
    status_log = f"/run/openvpn-server/{instancia}-status.log"

    online = {}
    lista = []

    online_text = subprocess.run(
        ["sudo", "cat", status_log],
        capture_output=True,
        text=True
    ).stdout

    for linha in online_text.splitlines():
        if linha.startswith("CLIENT_LIST"):
            partes = linha.split()
            if len(partes) >= 4:
                online[partes[1]] = partes[3]

    for f in os.listdir(pasta):
        if not f.endswith(".crt") or f in ("server.crt", f"{servidor}.crt"):
            continue

        nome = f[:-4]

        estado = "ONLINE" if nome in online else "OFFLINE"
        ipvpn = online.get(nome, "-")

        rede = "-"

        ccd = f"{ccd_dir}/{nome}"
        if os.path.exists(ccd):
            redes = []

            with open(ccd) as ficheiro:
                for linha in ficheiro:
                    linha = linha.strip()

                    if linha.startswith("ifconfig-push "):
                       partes = linha.split()
                       if len(partes) >= 2:
                           ipvpn = partes[1]

                    if linha.startswith("# rede_local="):
                        redes.append(linha.split("=",1)[1].strip())

                    elif linha.startswith("iroute"):
                        partes = linha.split()
                        if len(partes) >= 2:
                            redes.append(partes[1])

            if redes:
                rede = ", ".join(redes)

        lista.append({
            "nome": nome,
            "estado": estado,
            "ipvpn": ipvpn,
            "rede": rede
        })

    return render_template(
        "clientes.html",
        clientes=sorted(lista, key=lambda x: x["nome"].lower()),
        servidor=servidor,
        nome_servidor=nome_servidor
    )


from flask import request

@app.route("/criar", methods=["GET", "POST"])
@app.route("/criar/<servidor>", methods=["GET", "POST"])
@auth.login_required
def criar(servidor=None):
    if servidor is None:
        servidor = "servidor1"

    if request.method == "POST":
        nome = request.form["nome"]
        tipo = request.form["tipo"]

        if tipo == "casa":
            rede = request.form["rede_casa"]
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo,
                rede
            ])

        elif tipo == "fora":
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo
            ])

        elif tipo == "glinet":
            redes = request.form["redes"]
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo,
                redes
            ])

        return f"Cliente {nome} criado com sucesso.<br><br><a href='/clientes/{servidor}'>Ver clientes</a>"

    return render_template("criar.html")

@app.route("/download/<cliente>/<tipo>")
@auth.login_required
def download(cliente, tipo):
    import os

    if tipo == "vpn":
        ficheiro = f"/home/ubuntu/{cliente}.ovpn"
    elif tipo == "vps":
        ficheiro = f"/home/ubuntu/{cliente}-vps.ovpn"
    else:
        return "Tipo invÃƒÆ’Ã‚Â¡lido", 404

    if not os.path.exists(ficheiro):
        return "Ficheiro nÃƒÆ’Ã‚Â£o encontrado", 404

    return send_file(ficheiro, as_attachment=True)

@app.route("/apagar/<servidor>/<cliente>", methods=["POST"])
@auth.login_required
def apagar_cliente(servidor, cliente):
    subprocess.run(
        [
            "sudo",
            "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
            servidor,
            "remover",
            cliente,
        ],
        check=True,
    )
    return redirect(url_for("clientes", servidor=servidor))
@app.route("/servidores")
@auth.login_required
def servidores():
    config = carregar_servidores()
    lista = []

    for secao in config.sections():
        lista.append({
            "id": secao,
            "nome": config[secao].get("NOME", secao),
            "porta": config[secao].get("PORTA", ""),
            "vpn": config[secao].get("VPN_PREFIX", ""),
            "ativo": config[secao].get("ATIVO", "1")
        })

    return render_template("servidores.html", servidores=lista)

@app.route("/servidores/apagar/<servidor_id>", methods=["POST"])
@auth.login_required
def apagar_servidor(servidor_id):
    config = carregar_servidores()

    if servidor_id not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor_id]

    vpn_prefix = dados.get("VPN_PREFIX", "")
    easy_rsa = dados.get("EASYRSA_DIR", "")
    server_conf = dados.get("SERVER_CONF", "")
    ccd_dir = dados.get("CCD_DIR", "")
    service = dados.get("SERVICE", f"openvpn-server@{servidor_id}")
    remote_conf = dados.get("REMOTE_CONFIG", "")

    # Parar e desativar o servidor
    subprocess.run(
        ["sudo", "systemctl", "stop", service],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    subprocess.run(
        ["sudo", "systemctl", "disable", service],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Apagar ficheiros .ovpn dos clientes deste servidor
    issued_dir = f"{easy_rsa}/pki/issued"

    if os.path.isdir(issued_dir):
        for ficheiro in os.listdir(issued_dir):
            if ficheiro.endswith(".crt"):
                cliente = ficheiro[:-4]

                if cliente != servidor_id:
                    subprocess.run(
                        ["sudo", "rm", "-f",
                         f"/home/ubuntu/{cliente}.ovpn",
                         f"/home/ubuntu/{cliente}-vps.ovpn"]
                    )

    # Apagar configuração, PKI e CCD
    for caminho in [easy_rsa, ccd_dir]:
        if caminho:
            subprocess.run(["sudo", "rm", "-rf", caminho])

    for caminho in [server_conf, remote_conf]:
        if caminho:
            subprocess.run(["sudo", "rm", "-f", caminho])

    # Apagar regras de rede deste servidor
    if vpn_prefix:
        rede_vpn = f"{vpn_prefix}.0/24"

        while subprocess.run(
            [
                "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ).returncode == 0:
            subprocess.run(
                [
                    "sudo", "iptables", "-t", "nat", "-D", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ]
            )

        subprocess.run(
            ["sudo", "iptables", "-D", "FORWARD",
             "-s", rede_vpn, "-j", "ACCEPT"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        subprocess.run(
            ["sudo", "iptables", "-D", "FORWARD",
             "-d", rede_vpn, "-m", "conntrack",
             "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

            # Apagar regras de isolamento deste servidor
        tun_apagar = f"tun-{servidor_id}"

        for outro in config.sections():
            if outro == servidor_id:
                continue

            tun_outro = f"tun-{outro}"

            while subprocess.run(
                [
                    "sudo", "iptables", "-C", "FORWARD",
                    "-i", tun_apagar,
                    "-o", tun_outro,
                    "-j", "DROP"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode == 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-D", "FORWARD",
                        "-i", tun_apagar,
                        "-o", tun_outro,
                        "-j", "DROP"
                    ],
                    check=True
                )

            while subprocess.run(
                [
                    "sudo", "iptables", "-C", "FORWARD",
                    "-i", tun_outro,
                    "-o", tun_apagar,
                    "-j", "DROP"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode == 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-D", "FORWARD",
                        "-i", tun_outro,
                        "-o", tun_apagar,
                        "-j", "DROP"
                    ],
                    check=True
                ) 

    # Retirar do servidores.conf
    config.remove_section(servidor_id)

    with open(SERVIDORES_CONF, "w") as ficheiro:
        config.write(ficheiro)

    # Guardar regras iptables
    subprocess.run(
        ["sudo", "netfilter-persistent", "save"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    return redirect(url_for("servidores"))

@app.route("/servidores/adicionar", methods=["GET", "POST"])
@auth.login_required
def adicionar_servidor():
    if request.method == "POST":
        nome = request.form["nome"].strip()
        porta = request.form["porta"].strip()
        vpn_prefix = request.form["vpn_prefix"].strip()
        remote_host = request.form["remote_host"].strip()

        config = carregar_servidores()

        numero = 1
        while f"servidor{numero}" in config.sections():
            numero += 1

        secao = f"servidor{numero}"

        easyrsa_dir = f"/etc/openvpn/{secao}-easy-rsa"
        pki_dir = f"{easyrsa_dir}/pki"
        ccd_dir = f"/etc/openvpn/ccd-{secao}"
        server_conf = f"/etc/openvpn/server/{secao}.conf"
        remote_conf = f"/etc/openvpn/remote-host-{secao}.conf"

        try:
            # Criar estrutura Easy-RSA nova
            subprocess.run(
                ["sudo", "mkdir", "-p", easyrsa_dir],
                check=True
            )

            subprocess.run(
                [
                    "sudo", "cp",
                    "/usr/share/easy-rsa/easyrsa",
                    easyrsa_dir + "/easyrsa"
                ],
                check=True
            )

            subprocess.run(
                ["sudo", "chmod", "+x", easyrsa_dir + "/easyrsa"],
                check=True
            )

            # Criar PKI nova
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "init-pki"
                ],
                check=True
            )

            # Criar CA automática
            env = os.environ.copy()
            env["EASYRSA_BATCH"] = "1"
            env["EASYRSA_REQ_CN"] = f"{secao}-CA"

            subprocess.run(
                [
                    "sudo", "-E",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "build-ca",
                    "nopass"
                ],
                check=True,
                env=env
            )

            # Criar certificado do servidor
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "--batch",
                    "build-server-full",
                    secao,
                    "nopass"
                ],
                check=True,
            )

            # DH
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "gen-dh"
                ],
                check=True
            )

            # CRL
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "gen-crl"
                ],
                check=True
            )

            # TLS key
            subprocess.run(
                [
                    "sudo", "openvpn",
                    "--genkey", "secret",
                    f"{pki_dir}/ta.key"
                ],
                check=True
            )

            # CCD próprio
            subprocess.run(
                ["sudo", "mkdir", "-p", ccd_dir],
                check=True
            )

            # Criar configuração OpenVPN
            conteudo = f"""port {porta}
proto udp
dev tun-{secao}

topology subnet
server {vpn_prefix}.0 255.255.255.0

ca {pki_dir}/ca.crt
cert {pki_dir}/issued/{secao}.crt
key {pki_dir}/private/{secao}.key
dh {pki_dir}/dh.pem
tls-crypt {pki_dir}/ta.key

verify-client-cert require
remote-cert-tls client
tls-version-min 1.2

data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305
data-ciphers-fallback AES-256-GCM
auth SHA256

client-to-client
keepalive 10 120
persist-key
persist-tun

user nobody
group nogroup

status /run/openvpn-server/{secao}-status.log
status-version 3
verb 3
explicit-exit-notify 1
client-config-dir {ccd_dir}
crl-verify {pki_dir}/crl.pem
"""

            subprocess.run(
                ["sudo", "tee", server_conf],
                input=conteudo,
                text=True,
                stdout=subprocess.DEVNULL,
                check=True
            )

            # Criar ficheiro remoto
            subprocess.run(
                ["sudo", "touch", remote_conf],
                check=True
            )

            # Ativar e arrancar automaticamente
            subprocess.run(
                ["sudo", "systemctl", "enable", f"openvpn-server@{secao}"],
                check=True
            )

            subprocess.run(
                ["sudo", "systemctl", "restart", f"openvpn-server@{secao}"],
                check=True
            )

            # Criar NAT para a rede VPN deste servidor
            rede_vpn = f"{vpn_prefix}.0/24"

            subprocess.run(
                 [
                    "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

            if subprocess.run(
                [
                    "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode != 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-t", "nat", "-A", "POSTROUTING",
                        "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                    ],
                    check=True
                )
                    # Isolar este servidor dos outros servidores OpenVPN
                tun_novo = f"tun-{secao}"
        
                for outro in config.sections():
                    tun_outro = f"tun-{outro}"
        
                    # Novo -> outro
                    if subprocess.run(
                        [
                            "sudo", "iptables", "-C", "FORWARD",
                            "-i", tun_novo,
                            "-o", tun_outro,
                            "-j", "DROP"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    ).returncode != 0:
                        subprocess.run(
                            [
                                "sudo", "iptables", "-A", "FORWARD",
                                "-i", tun_novo,
                                "-o", tun_outro,
                                "-j", "DROP"
                            ],
                            check=True
                        )
        
                    # Outro -> novo
                    if subprocess.run(
                        [
                            "sudo", "iptables", "-C", "FORWARD",
                            "-i", tun_outro,
                            "-o", tun_novo,
                            "-j", "DROP"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    ).returncode != 0:
                        subprocess.run(
                            [
                                "sudo", "iptables", "-A", "FORWARD",
                                "-i", tun_outro,
                                "-o", tun_novo,
                                "-j", "DROP"
                            ],
                            check=True
                        )
        
            subprocess.run(
                ["sudo", "netfilter-persistent", "save"],
                check=True
            )

        except subprocess.CalledProcessError as e:
            return f"Erro ao criar {secao}: {e}", 500

        # Só grava no painel depois de tudo criado
        config[secao] = {
            "NOME": nome,
            "PORTA": porta,
            "VPN_PREFIX": vpn_prefix,
            "VPN_NETMASK": "255.255.255.0",
            "REMOTE_HOST": remote_host,
            "EASYRSA_DIR": easyrsa_dir,
            "SERVER_CONF": server_conf,
            "CCD_DIR": ccd_dir,
            "SERVICE": f"openvpn-server@{secao}",
            "REMOTE_CONFIG": remote_conf,
            "ATIVO": "1"
        }

        with open(SERVIDORES_CONF, "w") as ficheiro:
            config.write(ficheiro)

        return redirect(url_for("servidores"))

    return render_template("adicionar_servidor.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)

